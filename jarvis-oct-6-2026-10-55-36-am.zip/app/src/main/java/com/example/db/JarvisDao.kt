package com.example.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.ChatMessage
import com.example.model.KnowledgeRelation
import com.example.model.MemoryNode
import com.example.model.ReasoningExperience
import com.example.model.UserFramework
import kotlinx.coroutines.flow.Flow

@Dao
interface JarvisDao {
    // Memory Nodes
    @Query("SELECT * FROM memory_nodes WHERE isActive = 1 ORDER BY timestamp DESC")
    fun getAllActiveMemoriesFlow(): Flow<List<MemoryNode>>

    @Query("SELECT * FROM memory_nodes WHERE isActive = 1 ORDER BY timestamp DESC")
    suspend fun getAllActiveMemories(): List<MemoryNode>

    @Query("SELECT * FROM memory_nodes WHERE id = :id LIMIT 1")
    suspend fun getMemoryById(id: Long): MemoryNode?

    @Query("SELECT * FROM memory_nodes WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' AND isActive = 1")
    suspend fun searchMemories(query: String): List<MemoryNode>

    @Query("SELECT * FROM memory_nodes WHERE frameworkName = :framework AND isActive = 1")
    suspend fun getMemoriesByFramework(framework: String): List<MemoryNode>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(node: MemoryNode): Long

    @Update
    suspend fun updateMemory(node: MemoryNode)

    @Query("UPDATE memory_nodes SET isActive = 0 WHERE id = :id")
    suspend fun deactivateMemory(id: Long)

    @Query("DELETE FROM memory_nodes WHERE id = :id")
    suspend fun deleteMemory(id: Long)

    // Knowledge Relations
    @Query("SELECT * FROM knowledge_relations ORDER BY id DESC")
    fun getAllRelationsFlow(): Flow<List<KnowledgeRelation>>

    @Query("SELECT * FROM knowledge_relations ORDER BY id DESC")
    suspend fun getAllRelations(): List<KnowledgeRelation>

    @Query("SELECT * FROM knowledge_relations WHERE fromConcept = :concept OR toConcept = :concept")
    suspend fun getRelationsForConcept(concept: String): List<KnowledgeRelation>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRelation(relation: KnowledgeRelation): Long

    @Query("DELETE FROM knowledge_relations WHERE id = :id")
    suspend fun deleteRelation(id: Long)

    // User Frameworks
    @Query("SELECT * FROM user_frameworks ORDER BY name ASC")
    fun getAllFrameworksFlow(): Flow<List<UserFramework>>

    @Query("SELECT * FROM user_frameworks ORDER BY name ASC")
    suspend fun getAllFrameworks(): List<UserFramework>

    @Query("SELECT * FROM user_frameworks WHERE LOWER(name) = LOWER(:name) LIMIT 1")
    suspend fun getFrameworkByName(name: String): UserFramework?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFramework(framework: UserFramework): Long

    @Query("DELETE FROM user_frameworks WHERE id = :id")
    suspend fun deleteFramework(id: Long)

    // Reasoning Experiences
    @Query("SELECT * FROM reasoning_experiences ORDER BY timestamp DESC")
    fun getAllExperiencesFlow(): Flow<List<ReasoningExperience>>

    @Query("SELECT * FROM reasoning_experiences ORDER BY timestamp DESC")
    suspend fun getAllExperiences(): List<ReasoningExperience>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExperience(experience: ReasoningExperience): Long

    // Chat History
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllChatMessagesFlow(): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessage): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearChatMessages()
}
