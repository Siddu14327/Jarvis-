package com.example.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.model.ChatMessage
import com.example.model.EpistemicStatus
import com.example.model.KnowledgeRelation
import com.example.model.MemoryNode
import com.example.model.MemoryType
import com.example.model.ReasoningExperience
import com.example.model.RelationType
import com.example.model.UserFramework

class Converters {
    @TypeConverter
    fun fromMemoryType(value: MemoryType): String = value.name

    @TypeConverter
    fun toMemoryType(value: String): MemoryType = runCatching {
        MemoryType.valueOf(value)
    }.getOrDefault(MemoryType.FACT)

    @TypeConverter
    fun fromEpistemicStatus(value: EpistemicStatus): String = value.name

    @TypeConverter
    fun toEpistemicStatus(value: String): EpistemicStatus = runCatching {
        EpistemicStatus.valueOf(value)
    }.getOrDefault(EpistemicStatus.FACT)

    @TypeConverter
    fun fromRelationType(value: RelationType): String = value.name

    @TypeConverter
    fun toRelationType(value: String): RelationType = runCatching {
        RelationType.valueOf(value)
    }.getOrDefault(RelationType.RELATED_TO)
}

@Database(
    entities = [
        MemoryNode::class,
        KnowledgeRelation::class,
        UserFramework::class,
        ReasoningExperience::class,
        ChatMessage::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun dao(): JarvisDao

    companion object {
        @Volatile
        private var INSTANCE: JarvisDatabase? = null

        fun getInstance(context: Context): JarvisDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    JarvisDatabase::class.java,
                    "jarvis_cognitive_core.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
