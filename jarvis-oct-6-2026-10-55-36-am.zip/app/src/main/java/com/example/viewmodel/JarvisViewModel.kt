package com.example.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.cognitive.CalculationEngine
import com.example.cognitive.CognitiveCore
import com.example.cognitive.CognitiveResult
import com.example.cognitive.ContradictionDetector
import com.example.cognitive.FileUnderstandingEngine
import com.example.cognitive.GeminiReasoningEngine
import com.example.cognitive.MatrixEngine
import com.example.cognitive.PipelineStepExecution
import com.example.cognitive.SimulationEngine
import com.example.db.JarvisDatabase
import com.example.model.ChatMessage
import com.example.model.KnowledgeRelation
import com.example.model.MemoryNode
import com.example.model.ReasoningExperience
import com.example.model.UserFramework
import com.example.repository.JarvisRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AttachedFileInfo(
    val uri: Uri,
    val name: String,
    val summary: String,
    val content: String
)

class JarvisViewModel(context: Context) : ViewModel() {

    private val db = JarvisDatabase.getInstance(context)
    private val dao = db.dao()
    private val repository = JarvisRepository(dao)

    private val fileUnderstandingEngine = FileUnderstandingEngine(context)
    private val cognitiveCore = CognitiveCore(
        dao = dao,
        calculationEngine = CalculationEngine(),
        matrixEngine = MatrixEngine(),
        simulationEngine = SimulationEngine(),
        contradictionDetector = ContradictionDetector(),
        reasoningEngine = GeminiReasoningEngine()
    )

    val chatMessages: StateFlow<List<ChatMessage>> = repository.chatMessagesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memories: StateFlow<List<MemoryNode>> = repository.activeMemoriesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val relations: StateFlow<List<KnowledgeRelation>> = repository.relationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val frameworks: StateFlow<List<UserFramework>> = repository.frameworksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val experiences: StateFlow<List<ReasoningExperience>> = repository.experiencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _lastCognitiveResult = MutableStateFlow<CognitiveResult?>(null)
    val lastCognitiveResult: StateFlow<CognitiveResult?> = _lastCognitiveResult.asStateFlow()

    private val _attachedFile = MutableStateFlow<AttachedFileInfo?>(null)
    val attachedFile: StateFlow<AttachedFileInfo?> = _attachedFile.asStateFlow()

    fun attachFile(uri: Uri) {
        viewModelScope.launch {
            val parsed = fileUnderstandingEngine.processUri(uri)
            _attachedFile.value = AttachedFileInfo(
                uri = uri,
                name = parsed.fileName,
                summary = parsed.structuralSummary,
                content = parsed.extractedText
            )
        }
    }

    fun clearAttachedFile() {
        _attachedFile.value = null
    }

    fun submitQuery(userText: String) {
        val query = userText.trim()
        if (query.isEmpty() && _attachedFile.value == null) return

        val attached = _attachedFile.value
        _attachedFile.value = null
        _isProcessing.value = true

        viewModelScope.launch {
            val userMsg = ChatMessage(
                isUser = true,
                text = query.ifEmpty { "Analyze attached file: ${attached?.name}" },
                attachedFileName = attached?.name,
                attachedFileContent = attached?.content
            )
            repository.insertChatMessage(userMsg)

            val cognitiveResult = cognitiveCore.processInput(
                text = if (query.isNotEmpty()) query else "Analyze and assimilate file content: ${attached?.summary}",
                attachedFileName = attached?.name,
                attachedFileContent = attached?.content
            )

            _lastCognitiveResult.value = cognitiveResult
            _isProcessing.value = false
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearChatMessages()
            _lastCognitiveResult.value = null
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            repository.deleteMemory(id)
        }
    }

    fun deleteRelation(id: Long) {
        viewModelScope.launch {
            repository.deleteRelation(id)
        }
    }

    fun deleteFramework(id: Long) {
        viewModelScope.launch {
            repository.deleteFramework(id)
        }
    }
}

class JarvisViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(JarvisViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return JarvisViewModel(context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
