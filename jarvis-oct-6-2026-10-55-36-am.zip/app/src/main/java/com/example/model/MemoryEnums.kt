package com.example.model

/**
 * Categorization of cognitive memory item types according to JARVIS core specs.
 */
enum class MemoryType {
    FACT,
    INSTRUCTION,
    PREFERENCE,
    DEFINITION,
    USER_CONCEPT,
    RULE,
    FORMULA,
    FRAMEWORK,
    OBSERVATION,
    EXPERIMENT,
    RESULT,
    EXPERIENCE,
    CORRECTION,
    MISTAKE,
    SUCCESSFUL_STRATEGY,
    FAILED_STRATEGY,
    PATTERN,
    FILE_KNOWLEDGE
}

enum class EpistemicStatus {
    FACT,
    USER_DEFINED_RULE,
    HIGH_CONFIDENCE_CONCLUSION,
    OBSERVATION,
    INFERENCE,
    HYPOTHESIS,
    SPECULATION,
    UNCERTAIN
}

enum class RelationType {
    RELATED_TO,
    CAUSES,
    AFFECTS,
    CONTRADICTS,
    SUPPORTS,
    DEPENDS_ON,
    DERIVED_FROM,
    SIMILAR_TO,
    OPPOSITE_OF,
    MODIFIES,
    APPLIES_TO,
    OBSERVED_WITH,
    TESTED_BY
}
