package com.example.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Structured long-term memory node.
 */
@Entity(
    tableName = "memory_nodes",
    indices = [
        Index(value = ["title"]),
        Index(value = ["type"]),
        Index(value = ["frameworkName"]),
        Index(value = ["isActive"])
    ]
)
data class MemoryNode(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val type: MemoryType,
    val epistemicStatus: EpistemicStatus = EpistemicStatus.FACT,
    val frameworkName: String? = null,
    val tags: String = "", // Comma-separated tags
    val source: String = "user_interaction",
    val importance: Float = 0.8f, // 0.0 - 1.0
    val confidence: Float = 1.0f, // 0.0 - 1.0
    val version: Int = 1,
    val isActive: Boolean = true,
    val verificationNotes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Relationship graph edges connecting concepts, rules, observations, and frameworks.
 */
@Entity(
    tableName = "knowledge_relations",
    indices = [
        Index(value = ["fromConcept"]),
        Index(value = ["toConcept"]),
        Index(value = ["relationType"])
    ]
)
data class KnowledgeRelation(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fromConcept: String,
    val toConcept: String,
    val relationType: RelationType,
    val weight: Float = 1.0f,
    val description: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Custom Framework definition (e.g., Matrix, Vehicle Framework, etc.)
 */
@Entity(
    tableName = "user_frameworks",
    indices = [Index(value = ["name"], unique = true)]
)
data class UserFramework(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val description: String,
    val variablesJson: String = "[]", // List of variable names/definitions
    val rulesJson: String = "[]", // List of framework specific rule strings
    val version: Int = 1,
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Learning experience ledger: problem, approach, outcome, lesson learned.
 */
@Entity(tableName = "reasoning_experiences")
data class ReasoningExperience(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val problem: String,
    val approach: String,
    val result: String,
    val wasSuccessful: Boolean,
    val correction: String = "",
    val lessonLearned: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Session chat message.
 */
@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val isUser: Boolean,
    val text: String,
    val reasoningSummary: String? = null,
    val attachedFileName: String? = null,
    val attachedFileContent: String? = null,
    val retrievedMemoryCount: Int = 0,
    val calculationPerformed: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
