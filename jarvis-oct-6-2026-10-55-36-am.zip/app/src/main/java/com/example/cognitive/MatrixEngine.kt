package com.example.cognitive

import com.example.model.EpistemicStatus
import com.example.model.KnowledgeRelation
import com.example.model.MemoryNode
import com.example.model.MemoryType
import com.example.model.RelationType
import com.example.model.UserFramework

/**
 * System Multi-Variable Matrix Analysis Engine.
 * Analyzes interacting components, properties, dominant effects, supporting effects,
 * containment, amplification, conflicts, and synthesizes overall system outcome.
 */
class MatrixEngine {

    data class ComponentAnalysis(
        val name: String,
        val attributes: Map<String, String>,
        val planetaryOrSymbolicAssociation: String? = null,
        val fieldWeight: Float = 1.0f
    )

    data class MatrixResult(
        val componentsIdentified: List<ComponentAnalysis>,
        val primaryInteractions: List<String>,
        val dominantEffects: List<String>,
        val supportingEffects: List<String>,
        val conflictingEffects: List<String>,
        val containmentAndAmplification: String,
        val syntheticSystemOutcome: String,
        val epistemicStatus: EpistemicStatus = EpistemicStatus.INFERENCE
    )

    /**
     * Executes systemic multi-variable matrix analysis on input query considering retrieved memories and frameworks.
     */
    fun analyze(
        input: String,
        activeFramework: UserFramework?,
        relatedMemories: List<MemoryNode>,
        relations: List<KnowledgeRelation>
    ): MatrixResult {
        val lower = input.lowercase()

        // 1. Identify components mentioned (e.g. walls, ceiling, seats, exterior, interior, engine, driver, etc.)
        val components = mutableListOf<ComponentAnalysis>()

        // Colors extractor
        val knownColors = listOf("white", "red", "black", "blue", "green", "yellow", "silver", "gold", "orange", "grey", "gray")
        val knownElements = listOf("wall", "walls", "ceiling", "seat", "seats", "floor", "exterior", "interior", "cabin", "base", "frame", "driver", "vehicle")

        for (elem in knownElements) {
            if (lower.contains(elem)) {
                // Find associated color or attribute near it
                val matchedColor = knownColors.firstOrNull { col ->
                    val pat1 = "$col $elem"
                    val pat2 = "$elem.*$col"
                    val pat3 = "$elem is $col"
                    val pat4 = "all-$col $elem"
                    lower.contains(pat1) || lower.contains("all-$col") && lower.contains(elem) || Regex("$elem[^.,;]{0,15}$col").containsMatchIn(lower) || Regex("$col[^.,;]{0,15}$elem").containsMatchIn(lower)
                }
                val attrs = mutableMapOf<String, String>()
                if (matchedColor != null) {
                    attrs["color"] = matchedColor
                }
                // Check if mentioned in memories
                val memoryRef = relatedMemories.firstOrNull { it.content.contains(elem, ignoreCase = true) }
                if (memoryRef != null) {
                    attrs["stored_rule"] = memoryRef.title
                }

                components.add(
                    ComponentAnalysis(
                        name = elem.capitalize(),
                        attributes = attrs,
                        planetaryOrSymbolicAssociation = derivePlanetaryAssociation(matchedColor, elem),
                        fieldWeight = if (elem.contains("wall") || elem.contains("seat") || elem.contains("base")) 1.5f else 1.0f
                    )
                )
            }
        }

        // If no predefined elements matched, extract generic entities
        if (components.isEmpty()) {
            val words = input.split(Regex("[\\s,;]+")).filter { it.length > 3 }
            for (w in words.take(4)) {
                components.add(ComponentAnalysis(name = w, attributes = emptyMap()))
            }
        }

        // 2. Identify Interactions from Knowledge Graph and Stored Rules
        val interactions = mutableListOf<String>()
        val dominant = mutableListOf<String>()
        val supporting = mutableListOf<String>()
        val conflicting = mutableListOf<String>()

        // Detect colors interaction (e.g., White (calm/purity/lunar) + Red (action/heat/mars))
        val colorsPresent = components.mapNotNull { it.attributes["color"] }.distinct()
        if (colorsPresent.contains("white") && colorsPresent.contains("red")) {
            interactions.add("Interplay between White (reflection, expansion, containment) and Red (intensity, ignition, focal concentration).")
            dominant.add("White walls create an amplified reflective envelope; Red seating concentrates internal observer focus.")
            supporting.add("Contrast gradient enhances alertness while spatial enclosure remains expansive.")
            conflicting.add("Potential tension between cooling/static field (White) and dynamic/stimulative point of contact (Red).")
        }

        // Check active framework rules
        if (activeFramework != null) {
            interactions.add("Evaluated under user framework '${activeFramework.name}': applying priority matrices and variable constraints.")
            dominant.add("Framework rule-set '${activeFramework.name}' dictates priority over baseline heuristics.")
        }

        // Check relations graph
        for (rel in relations) {
            when (rel.relationType) {
                RelationType.CONTRADICTS, RelationType.OPPOSITE_OF -> {
                    conflicting.add("${rel.fromConcept} contradicts ${rel.toConcept}: ${rel.description}")
                }
                RelationType.SUPPORTS -> {
                    supporting.add("${rel.fromConcept} supports ${rel.toConcept}: ${rel.description}")
                }
                RelationType.CAUSES, RelationType.AFFECTS -> {
                    dominant.add("${rel.fromConcept} affects ${rel.toConcept}: ${rel.description}")
                }
                else -> {
                    interactions.add("${rel.fromConcept} --[${rel.relationType}]--> ${rel.toConcept}")
                }
            }
        }

        // Synthesize Containment & Amplification
        val containment = if (colorsPresent.contains("white") && colorsPresent.contains("red")) {
            "Containment Field: White boundary acts as a diffuse reflector, preventing dispersion while insulating the core. Amplification Field: Red contact surfaces receive heightened energy resonance without thermal scatter."
        } else {
            "Equilibrium Field: Components distribute systemic charge proportionally across active boundaries."
        }

        // Synthetic conclusion
        val outcome = buildString {
            append("Matrix System Assessment: ")
            if (components.isNotEmpty()) {
                append("Synthesized ${components.size} multi-variable components. ")
            }
            if (dominant.isNotEmpty()) {
                append("Primary driver: ${dominant.first()}. ")
            }
            if (conflicting.isNotEmpty()) {
                append("Critical tension identified: ${conflicting.first()}. ")
            }
            append("Net system behavior shows cohesive dynamic balance rather than isolated component summation.")
        }

        return MatrixResult(
            componentsIdentified = components,
            primaryInteractions = interactions,
            dominantEffects = dominant,
            supportingEffects = supporting,
            conflictingEffects = conflicting,
            containmentAndAmplification = containment,
            syntheticSystemOutcome = outcome,
            epistemicStatus = if (activeFramework != null) EpistemicStatus.USER_DEFINED_RULE else EpistemicStatus.INFERENCE
        )
    }

    private fun derivePlanetaryAssociation(color: String?, component: String): String? {
        return when (color?.lowercase()) {
            "red" -> "Mars (Dynamic / Heat / Drive)"
            "white" -> "Moon / Venus (Clarity / Reflection / Harmony)"
            "black" -> "Saturn (Absorption / Structure / Grounding)"
            "yellow" -> "Jupiter (Expansion / Radiance)"
            "green" -> "Mercury (Adaptability / Vitality)"
            "blue" -> "Saturn / Jupiter (Depth / Focus)"
            else -> null
        }
    }

    private fun String.capitalize(): String = replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
}
