package com.example.cognitive

import com.example.model.EpistemicStatus
import com.example.model.KnowledgeRelation
import com.example.model.MemoryNode
import com.example.model.MemoryType
import com.example.model.UserFramework

/**
 * Interface decoupling the AI reasoning engine from the underlying provider (Gemini, local, etc.)
 */
interface ReasoningEngine {
    data class ReasoningContext(
        val userInput: String,
        val relevantMemories: List<MemoryNode>,
        val activeFrameworks: List<UserFramework>,
        val relations: List<KnowledgeRelation>,
        val calculationSummary: String?,
        val matrixSummary: String?,
        val simulationSummary: String?,
        val auditWarnings: String?,
        val attachedFileContent: String?
    )

    data class ReasoningOutput(
        val fullAnswer: String,
        val reasoningSummary: String,
        val epistemicStatus: EpistemicStatus,
        val newConceptsToRemember: List<MemoryNode> = emptyList(),
        val newRelationsToConnect: List<KnowledgeRelation> = emptyList(),
        val confidence: Float = 0.95f
    )

    suspend fun reason(context: ReasoningContext): ReasoningOutput
}
