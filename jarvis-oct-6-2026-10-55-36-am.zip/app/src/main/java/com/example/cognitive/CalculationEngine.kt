package com.example.cognitive

import java.util.Locale
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Deterministic Calculation Engine
 * Handles arithmetic, conversions, percentages, ratios, statistics, expressions, formulas.
 * "CALCULATE FIRST -> VERIFY -> THEN EXPLAIN. Never invent a numerical result."
 */
class CalculationEngine {

    data class CalculationResult(
        val formulaOrExpression: String,
        val resultString: String,
        val numericValue: Double?,
        val explanation: String
    )

    /**
     * Attempts to identify and solve mathematical requests deterministically.
     */
    fun evaluate(input: String): CalculationResult? {
        val trimmed = input.trim()

        // 1. Check for basic arithmetic expressions like "(12 + 45) * 3 / 2", "sqrt(144)", "2^8"
        val cleanExpr = extractMathExpression(trimmed)
        if (cleanExpr != null) {
            val evaluated = runCatching { evaluateExpression(cleanExpr) }.getOrNull()
            if (evaluated != null) {
                val formatted = if (evaluated % 1.0 == 0.0) evaluated.toLong().toString() else String.format(Locale.US, "%.4f", evaluated).trimEnd('0').trimEnd('.')
                return CalculationResult(
                    formulaOrExpression = cleanExpr,
                    resultString = formatted,
                    numericValue = evaluated,
                    explanation = "Deterministic Evaluation: $cleanExpr = $formatted"
                )
            }
        }

        // 2. Check for percentage questions like "what is 15% of 850" or "increase 200 by 20%"
        val percentOfMatch = Regex("""(?:what\s+is\s+)?([0-9.]+)\s*%\s*(?:of)\s*([0-9.]+)""", RegexOption.IGNORE_CASE).find(trimmed)
        if (percentOfMatch != null) {
            val pct = percentOfMatch.groupValues[1].toDoubleOrNull()
            val base = percentOfMatch.groupValues[2].toDoubleOrNull()
            if (pct != null && base != null) {
                val res = (pct / 100.0) * base
                val formatted = if (res % 1.0 == 0.0) res.toLong().toString() else String.format(Locale.US, "%.4f", res)
                return CalculationResult(
                    formulaOrExpression = "$pct% of $base",
                    resultString = formatted,
                    numericValue = res,
                    explanation = "Deterministic Percentage: ($pct / 100) * $base = $formatted"
                )
            }
        }

        // 3. Ratio / Proportion: "ratio 3:5 with total 400"
        val ratioMatch = Regex("""ratio\s+([0-9]+)\s*:\s*([0-9]+)(?:\s+(?:with\s+)?total\s+([0-9.]+))?""", RegexOption.IGNORE_CASE).find(trimmed)
        if (ratioMatch != null) {
            val a = ratioMatch.groupValues[1].toDoubleOrNull() ?: 1.0
            val b = ratioMatch.groupValues[2].toDoubleOrNull() ?: 1.0
            val total = ratioMatch.groupValues.getOrNull(3)?.toDoubleOrNull()
            if (total != null) {
                val partA = total * (a / (a + b))
                val partB = total * (b / (a + b))
                return CalculationResult(
                    formulaOrExpression = "Ratio $a:$b on total $total",
                    resultString = "Part 1: $partA, Part 2: $partB",
                    numericValue = null,
                    explanation = "Deterministic Split: Total $total into ratio $a:$b -> $partA : $partB (Sum = ${partA + partB})"
                )
            }
        }

        // 4. Mean / Average / Statistics of numbers: "mean of [12, 15, 18, 20]" or "average: 4, 8, 15, 16, 23, 42"
        val statMatch = Regex("""(?:average|mean|median|stats|sum)\s*(?:of|:)?\s*\[?([0-9.,\s]+)\]?""", RegexOption.IGNORE_CASE).find(trimmed)
        if (statMatch != null) {
            val numbers = statMatch.groupValues[1]
                .split(',', ' ')
                .mapNotNull { it.trim().toDoubleOrNull() }
            if (numbers.isNotEmpty()) {
                val sum = numbers.sum()
                val mean = sum / numbers.size
                val sorted = numbers.sorted()
                val median = if (sorted.size % 2 == 1) sorted[sorted.size / 2] else (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0
                return CalculationResult(
                    formulaOrExpression = "Stats for ${numbers.size} values",
                    resultString = "Sum=$sum, Mean=$mean, Median=$median, Min=${sorted.first()}, Max=${sorted.last()}",
                    numericValue = mean,
                    explanation = "Deterministic Statistics: Count=${numbers.size}, Sum=$sum, Mean=$mean, Median=$median"
                )
            }
        }

        return null
    }

    private fun extractMathExpression(text: String): String? {
        val mathPrefixRegex = Regex("""(?:calculate|compute|solve|what\s+is|evaluate)?\s*([0-9\.\+\-\*\/\^\(\)\s%sqrt]+)$""", RegexOption.IGNORE_CASE)
        val match = mathPrefixRegex.find(text)
        val candidate = match?.groupValues?.get(1)?.trim() ?: text.trim()

        // Check if candidate has numbers and at least one operator
        val hasOperator = candidate.any { it in "+-*/^%" || candidate.contains("sqrt") }
        val hasDigit = candidate.any { it.isDigit() }
        val validChars = candidate.all { it.isDigit() || it in ".+-*/^%() sqrt" }

        return if (hasOperator && hasDigit && validChars && candidate.length >= 3) {
            candidate
        } else null
    }

    /**
     * Expression parser for arithmetic expressions with +, -, *, /, ^, sqrt.
     */
    fun evaluateExpression(str: String): Double {
        val parser = ExpressionParser(str)
        return parser.parse()
    }

    private class ExpressionParser(private val str: String) {
        var pos = -1
        var ch = 0

        fun nextChar() {
            ch = if (++pos < str.length) str[pos].code else -1
        }

        fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < str.length) error("Unexpected: " + ch.toChar())
            return x
        }

        fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                when {
                    eat('+'.code) -> x += parseTerm()
                    eat('-'.code) -> x -= parseTerm()
                    else -> return x
                }
            }
        }

        fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                when {
                    eat('*'.code) -> x *= parseFactor()
                    eat('/'.code) -> {
                        val divisor = parseFactor()
                        if (divisor == 0.0) error("Division by zero")
                        x /= divisor
                    }
                    eat('%'.code) -> x %= parseFactor()
                    else -> return x
                }
            }
        }

        fun parseFactor(): Double {
            if (eat('+'.code)) return +parseFactor()
            if (eat('-'.code)) return -parseFactor()

            var x: Double
            val startPos = pos
            if (eat('('.code)) {
                x = parseExpression()
                eat(')'.code)
            } else if (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) {
                while (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) nextChar()
                x = str.substring(startPos, pos).toDouble()
            } else if (ch >= 'a'.code && ch <= 'z'.code) {
                while (ch >= 'a'.code && ch <= 'z'.code) nextChar()
                val func = str.substring(startPos, pos)
                if (eat('('.code)) {
                    x = parseExpression()
                    eat(')'.code)
                } else {
                    x = parseFactor()
                }
                x = when (func) {
                    "sqrt" -> sqrt(x)
                    else -> error("Unknown function: $func")
                }
            } else {
                error("Unexpected character: " + ch.toChar())
            }

            if (eat('^'.code)) x = x.pow(parseFactor())

            return x
        }
    }
}
