package com.example.cognitive

import com.example.model.ChatMessage
import com.example.model.EpistemicStatus
import com.example.model.KnowledgeRelation
import com.example.model.MemoryNode
import com.example.model.UserFramework

enum class UserIntent {
    DIRECT_QUERY,
    TEACH_MEMORY,
    TEACH_FRAMEWORK,
    CONNECT_CONCEPTS,
    CORRECTION,
    SYSTEM_ANALYSIS,
    SCENARIO_SIMULATION,
    MATHEMATICAL_CALCULATION,
    FILE_ASSIMILATION
}

data class IntentClassification(
    val primaryIntent: UserIntent,
    val extractedEntities: List<String>,
    val targetFramework: String?,
    val confidence: Float
)

data class PipelineStepExecution(
    val stepName: String,
    val summary: String,
    val durationMs: Long,
    val status: String = "SUCCESS", // "SUCCESS", "SKIPPED", "ALERT"
    val details: String? = null
)

data class CognitiveResult(
    val finalResponse: String,
    val reasoningSummary: String,
    val intentClassification: IntentClassification,
    val pipelineSteps: List<PipelineStepExecution>,
    val retrievedMemories: List<MemoryNode>,
    val calculationPerformed: String?,
    val epistemicStatus: EpistemicStatus,
    val wasLearningCommitted: Boolean,
    val activeFramework: UserFramework?,
    val detectedContradictions: List<String> = emptyList(),
    val missingVariables: List<String> = emptyList()
)
