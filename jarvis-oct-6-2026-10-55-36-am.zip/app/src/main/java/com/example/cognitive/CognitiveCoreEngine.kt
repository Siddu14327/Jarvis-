package com.example.cognitive

import com.example.model.KnowledgeRelation
import com.example.model.MemoryNode
import com.example.model.UserFramework

/**
 * Foundation interface for the JARVIS Cognitive Core reasoning orchestration pipeline.
 */
interface CognitiveCoreEngine {

    /**
     * Ingests, parses, and initiates the multi-stage reasoning pipeline for user input.
     * Extracts variables, detects intent, and sets up working context.
     */
    suspend fun processInput(
        text: String,
        attachedFileName: String? = null,
        attachedFileContent: String? = null
    ): CognitiveResult

    /**
     * Actively searches persistent Room storage for semantic and relational memories
     * relevant to the query.
     */
    suspend fun retrieveMemory(query: String): List<MemoryNode>

    /**
     * Checks for contradictions, synthesizes all pipeline artifacts (retrievals, calculations,
     * framework rules, matrix analysis, simulations), logs experiences, and formats
     * the final answer.
     */
    suspend fun finalizeResponse(
        input: String,
        intent: IntentClassification,
        retrievedMemories: List<MemoryNode>,
        relations: List<KnowledgeRelation>,
        activeFramework: UserFramework?,
        calcResult: CalculationEngine.CalculationResult?,
        matrixResult: MatrixEngine.MatrixResult?,
        simulationResult: SimulationEngine.ScenarioComparison?,
        attachedFileName: String?,
        attachedFileContent: String?,
        steps: MutableList<PipelineStepExecution>
    ): CognitiveResult
}
