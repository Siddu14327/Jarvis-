package com.example.cognitive

import com.example.model.KnowledgeRelation
import com.example.model.MemoryNode
import com.example.model.RelationType

/**
 * Loophole Detection, Self-Checking, and Contradiction Engine
 * "Before finalizing important conclusions, check: missing variables, contradictions,
 * hidden assumptions, edge cases, exceptions, circular reasoning, invalid premises, conflicting rules."
 */
class ContradictionDetector {

    data class AuditResult(
        val hasContradiction: Boolean,
        val contradictionsFound: List<String>,
        val missingVariables: List<String>,
        val hiddenAssumptions: List<String>,
        val edgeCasesToConsider: List<String>,
        val confidenceAdjustment: Float, // 0.0 to 1.0 multiplier
        val warningMessage: String?
    )

    fun audit(
        query: String,
        memories: List<MemoryNode>,
        relations: List<KnowledgeRelation>,
        preliminaryAnswer: String?
    ): AuditResult {
        val contradictions = mutableListOf<String>()
        val missing = mutableListOf<String>()
        val assumptions = mutableListOf<String>()
        val edgeCases = mutableListOf<String>()

        val lowerQuery = query.lowercase()

        // 1. Check for contradictory rules in memory
        for (i in memories.indices) {
            for (j in i + 1 until memories.size) {
                val m1 = memories[i]
                val m2 = memories[j]
                if (m1.title.equals(m2.title, ignoreCase = true) && m1.content != m2.content) {
                    contradictions.add("Conflicting versions for '${m1.title}' (Version ${m1.version} vs Version ${m2.version})")
                }
            }
        }

        // 2. Check relations graph for explicit CONTRADICTS
        for (rel in relations) {
            if (rel.relationType == RelationType.CONTRADICTS) {
                if (lowerQuery.contains(rel.fromConcept.lowercase()) || lowerQuery.contains(rel.toConcept.lowercase())) {
                    contradictions.add("Graph Contradiction: '${rel.fromConcept}' explicitly contradicts '${rel.toConcept}' (${rel.description})")
                }
            }
        }

        // 3. Detect missing variables for vehicle / system setups
        if (lowerQuery.contains("setup") || lowerQuery.contains("vehicle") || lowerQuery.contains("rickshaw") || lowerQuery.contains("matrix")) {
            if (!lowerQuery.contains("base") && !memories.any { it.content.contains("base", ignoreCase = true) }) {
                missing.add("Base / Foundation specification is unspecified.")
            }
            if (!lowerQuery.contains("material") && !lowerQuery.contains("finish")) {
                missing.add("Material finish / texture properties are unspecified.")
            }
            if (!lowerQuery.contains("driver") && !lowerQuery.contains("observer")) {
                assumptions.add("Assumes standard static observer without dynamic driver interaction.")
            }
            edgeCases.add("High ambient lighting vs nocturnal operating conditions.")
        }

        // 4. Detect financial / trading / absolute guarantee claims
        if (lowerQuery.contains("guarantee") || lowerQuery.contains("100%") || lowerQuery.contains("always win") || lowerQuery.contains("surely")) {
            contradictions.add("Deterministic certainty cannot be assumed for open-system stochastic variables.")
        }

        val hasIssues = contradictions.isNotEmpty()
        val confAdj = if (hasIssues) 0.6f else if (missing.isNotEmpty()) 0.85f else 1.0f

        val warning = if (contradictions.isNotEmpty()) {
            "Contradiction alert: Found ${contradictions.size} conflicting premise(s): ${contradictions.joinToString("; ")}"
        } else if (missing.isNotEmpty()) {
            "Note on variables: Missing ${missing.joinToString(", ")}"
        } else null

        return AuditResult(
            hasContradiction = hasIssues,
            contradictionsFound = contradictions,
            missingVariables = missing,
            hiddenAssumptions = assumptions,
            edgeCasesToConsider = edgeCases,
            confidenceAdjustment = confAdj,
            warningMessage = warning
        )
    }
}
