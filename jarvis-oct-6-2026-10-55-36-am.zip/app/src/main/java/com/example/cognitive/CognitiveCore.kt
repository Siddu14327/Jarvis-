package com.example.cognitive

import com.example.db.JarvisDao
import com.example.model.ChatMessage
import com.example.model.EpistemicStatus
import com.example.model.KnowledgeRelation
import com.example.model.MemoryNode
import com.example.model.MemoryType
import com.example.model.ReasoningExperience
import com.example.model.RelationType
import com.example.model.UserFramework
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * JARVIS Central CognitiveCore Orchestrator
 *
 * Implements CognitiveCoreEngine with explicit lifecycle methods:
 * - processInput(text, attachedFileName, attachedFileContent)
 * - retrieveMemory(query)
 * - finalizeResponse(...)
 *
 * Coordinates the full multi-stage reasoning pipeline:
 * INPUT
 * ➔ understand the exact request & intent
 * ➔ identify entities and variables
 * ➔ retrieve relevant memory & knowledge
 * ➔ identify applicable frameworks
 * ➔ calculate deterministic values where required
 * ➔ perform matrix system analysis
 * ➔ simulate relevant outcomes
 * ➔ check contradictions & loopholes
 * ➔ synthesize strongest conclusion
 * ➔ store useful new knowledge / experience
 */
class CognitiveCore(
    private val dao: JarvisDao,
    private val calculationEngine: CalculationEngine = CalculationEngine(),
    private val matrixEngine: MatrixEngine = MatrixEngine(),
    private val simulationEngine: SimulationEngine = SimulationEngine(),
    private val contradictionDetector: ContradictionDetector = ContradictionDetector(),
    private val reasoningEngine: ReasoningEngine = GeminiReasoningEngine()
) : CognitiveCoreEngine {

    /**
     * Primary entry point for user text ingestion and pipeline coordination.
     */
    override suspend fun processInput(
        text: String,
        attachedFileName: String?,
        attachedFileContent: String?
    ): CognitiveResult = withContext(Dispatchers.IO) {
        val steps = mutableListOf<PipelineStepExecution>()
        val trimmed = text.trim()

        // Phase 1: Request Understanding & Intent Classification
        val step1Start = System.currentTimeMillis()
        val intent = classifyIntent(trimmed, attachedFileName)
        steps.add(
            PipelineStepExecution(
                stepName = "Request Understanding",
                summary = "Intent: ${intent.primaryIntent}; Entities: ${intent.extractedEntities.take(4).joinToString(", ")}",
                durationMs = System.currentTimeMillis() - step1Start
            )
        )

        // Teaching Mode Direct Interception
        if (intent.primaryIntent in listOf(
                UserIntent.TEACH_MEMORY,
                UserIntent.TEACH_FRAMEWORK,
                UserIntent.CONNECT_CONCEPTS,
                UserIntent.CORRECTION
            )
        ) {
            val teachResult = handleTeachingMode(trimmed, intent, steps, attachedFileName, attachedFileContent)
            if (teachResult != null) return@withContext teachResult
        }

        // Phase 2: Memory Retrieval
        val step2Start = System.currentTimeMillis()
        val retrievedMemories = retrieveMemory(trimmed)
        steps.add(
            PipelineStepExecution(
                stepName = "Memory Retrieval",
                summary = "Retrieved ${retrievedMemories.size} relevant persistent memory nodes",
                durationMs = System.currentTimeMillis() - step2Start,
                details = retrievedMemories.joinToString("\n") { "• [${it.type}] ${it.title}" }
            )
        )

        // Phase 3: Framework & Relational Graph Querying
        val step3Start = System.currentTimeMillis()
        val allFrameworks = dao.getAllFrameworks()
        val matchedFramework = allFrameworks.firstOrNull { f ->
            trimmed.contains(f.name, ignoreCase = true) ||
            intent.targetFramework?.equals(f.name, ignoreCase = true) == true ||
            retrievedMemories.any { it.frameworkName?.equals(f.name, ignoreCase = true) == true }
        }

        val searchTokens = extractSearchTokens(trimmed)
        val relations = mutableListOf<KnowledgeRelation>()
        searchTokens.forEach { token ->
            relations.addAll(dao.getRelationsForConcept(token))
        }
        val distinctRelations = relations.distinctBy { "${it.fromConcept}_${it.relationType}_${it.toConcept}" }
        steps.add(
            PipelineStepExecution(
                stepName = "Knowledge Graph & Frameworks",
                summary = if (matchedFramework != null) "Framework '${matchedFramework.name}' active with ${distinctRelations.size} graph relations"
                          else "${distinctRelations.size} graph relations connected",
                durationMs = System.currentTimeMillis() - step3Start
            )
        )

        // Phase 4: Deterministic Calculation Engine
        val step4Start = System.currentTimeMillis()
        val calcResult = calculationEngine.evaluate(trimmed)
        if (calcResult != null) {
            steps.add(
                PipelineStepExecution(
                    stepName = "Deterministic Calculation",
                    summary = "Evaluated: ${calcResult.formulaOrExpression} = ${calcResult.resultString}",
                    durationMs = System.currentTimeMillis() - step4Start,
                    details = calcResult.explanation
                )
            )
        } else {
            steps.add(
                PipelineStepExecution(
                    stepName = "Deterministic Calculation",
                    summary = "No exact numeric expression evaluated",
                    durationMs = System.currentTimeMillis() - step4Start,
                    status = "SKIPPED"
                )
            )
        }

        // Phase 5: Multi-Variable Matrix Analysis
        val step5Start = System.currentTimeMillis()
        val isMatrixTrigger = trimmed.contains("matrix", ignoreCase = true) ||
                trimmed.contains("setup", ignoreCase = true) ||
                trimmed.contains("vehicle", ignoreCase = true) ||
                trimmed.contains("walls", ignoreCase = true) ||
                trimmed.contains("seats", ignoreCase = true) ||
                intent.primaryIntent == UserIntent.SYSTEM_ANALYSIS

        val matrixResult = if (isMatrixTrigger) {
            matrixEngine.analyze(trimmed, matchedFramework, retrievedMemories, distinctRelations)
        } else null

        if (matrixResult != null) {
            steps.add(
                PipelineStepExecution(
                    stepName = "Multi-Variable Matrix Analysis",
                    summary = "Synthesized ${matrixResult.componentsIdentified.size} components; dominant: ${matrixResult.dominantEffects.firstOrNull() ?: "None"}",
                    durationMs = System.currentTimeMillis() - step5Start,
                    details = matrixResult.syntheticSystemOutcome
                )
            )
        }

        // Phase 6: Scenario Simulation
        val step6Start = System.currentTimeMillis()
        val isSimulationTrigger = trimmed.contains("what if", ignoreCase = true) ||
                trimmed.contains("what happens if", ignoreCase = true) ||
                (trimmed.contains("change", ignoreCase = true) && trimmed.contains("to", ignoreCase = true)) ||
                intent.primaryIntent == UserIntent.SCENARIO_SIMULATION

        val simulationResult = if (isSimulationTrigger) {
            simulationEngine.simulate(trimmed, retrievedMemories)
        } else null

        if (simulationResult != null) {
            steps.add(
                PipelineStepExecution(
                    stepName = "Scenario Simulation",
                    summary = "Compared: [${simulationResult.baseState}] vs [${simulationResult.proposedState}]",
                    durationMs = System.currentTimeMillis() - step6Start,
                    details = "Projected effects: ${simulationResult.projectedEffects.joinToString("; ")}"
                )
            )
        }

        // Phase 7 to 9: Contradiction Detection, Model Synthesis, Learning & Finalization
        finalizeResponse(
            input = trimmed,
            intent = intent,
            retrievedMemories = retrievedMemories,
            relations = distinctRelations,
            activeFramework = matchedFramework,
            calcResult = calcResult,
            matrixResult = matrixResult,
            simulationResult = simulationResult,
            attachedFileName = attachedFileName,
            attachedFileContent = attachedFileContent,
            steps = steps
        )
    }

    /**
     * Semantic and structured memory retrieval against persistent Room database.
     */
    override suspend fun retrieveMemory(query: String): List<MemoryNode> = withContext(Dispatchers.IO) {
        val tokens = extractSearchTokens(query)
        val allActive = dao.getAllActiveMemories()
        rankAndRetrieveMemories(tokens, allActive)
    }

    /**
     * Conducts loophole/contradiction checks, delegates synthesis to reasoning engine,
     * logs experiences into adaptive ledger, and persists chat messages.
     */
    override suspend fun finalizeResponse(
        input: String,
        intent: IntentClassification,
        retrievedMemories: List<MemoryNode>,
        relations: List<KnowledgeRelation>,
        activeFramework: UserFramework?,
        calcResult: CalculationEngine.CalculationResult?,
        matrixResult: MatrixEngine.MatrixResult?,
        simulationResult: SimulationEngine.ScenarioComparison?,
        attachedFileName: String?,
        attachedFileContent: String?,
        steps: MutableList<PipelineStepExecution>
    ): CognitiveResult = withContext(Dispatchers.IO) {
        // Step 7: Contradiction & Loophole Check
        val step7Start = System.currentTimeMillis()
        val auditResult = contradictionDetector.audit(
            query = input,
            memories = retrievedMemories,
            relations = relations,
            preliminaryAnswer = null
        )
        steps.add(
            PipelineStepExecution(
                stepName = "Loophole & Contradiction Audit",
                summary = if (auditResult.hasContradiction) "Alert: Contradictions identified (${auditResult.contradictionsFound.size})"
                          else if (auditResult.missingVariables.isNotEmpty()) "Audited: Missing variables noted (${auditResult.missingVariables.size})"
                          else "Audit verified: No logical contradictions detected",
                durationMs = System.currentTimeMillis() - step7Start,
                status = if (auditResult.hasContradiction) "ALERT" else "SUCCESS",
                details = auditResult.warningMessage
            )
        )

        // Step 8: Assemble Context for Reasoning Engine
        val step8Start = System.currentTimeMillis()
        val reasoningContext = ReasoningEngine.ReasoningContext(
            userInput = input,
            relevantMemories = retrievedMemories,
            activeFrameworks = if (activeFramework != null) listOf(activeFramework) else emptyList(),
            relations = relations,
            calculationSummary = calcResult?.explanation,
            matrixSummary = matrixResult?.let {
                "Components: ${it.componentsIdentified.map { c -> "${c.name} (${c.attributes})" }}; Dominant: ${it.dominantEffects}; Containment: ${it.containmentAndAmplification}; Outcome: ${it.syntheticSystemOutcome}"
            },
            simulationSummary = simulationResult?.let {
                "Scenario: Base [${it.baseState}] vs Proposed [${it.proposedState}]; Projected: ${it.projectedEffects}; Secondary: ${it.secondaryEffects}; Uncertainties: ${it.uncertainties}"
            },
            auditWarnings = auditResult.warningMessage,
            attachedFileContent = attachedFileContent
        )

        val reasoningOutput = reasoningEngine.reason(reasoningContext)
        steps.add(
            PipelineStepExecution(
                stepName = "Cognitive Synthesis",
                summary = "Status: ${reasoningOutput.epistemicStatus} (Confidence: ${(reasoningOutput.confidence * 100).toInt()}%)",
                durationMs = System.currentTimeMillis() - step8Start
            )
        )

        // Step 9: Adaptive Learning Ledger Record
        val experience = ReasoningExperience(
            problem = input,
            approach = "Pipeline steps executed: ${steps.size} (Calc: ${calcResult != null}, Matrix: ${matrixResult != null})",
            result = reasoningOutput.reasoningSummary,
            wasSuccessful = !auditResult.hasContradiction,
            correction = "",
            lessonLearned = if (activeFramework != null) "Framework ${activeFramework.name} applied." else "Systemic cognitive verification."
        )
        dao.insertExperience(experience)

        // Persist Bot Chat Message
        dao.insertChatMessage(
            ChatMessage(
                isUser = false,
                text = reasoningOutput.fullAnswer,
                reasoningSummary = reasoningOutput.reasoningSummary,
                attachedFileName = attachedFileName,
                attachedFileContent = attachedFileContent,
                retrievedMemoryCount = retrievedMemories.size,
                calculationPerformed = calcResult?.resultString
            )
        )

        CognitiveResult(
            finalResponse = reasoningOutput.fullAnswer,
            reasoningSummary = reasoningOutput.reasoningSummary,
            intentClassification = intent,
            pipelineSteps = steps,
            retrievedMemories = retrievedMemories,
            calculationPerformed = calcResult?.resultString,
            epistemicStatus = reasoningOutput.epistemicStatus,
            wasLearningCommitted = false,
            activeFramework = activeFramework,
            detectedContradictions = auditResult.contradictionsFound,
            missingVariables = auditResult.missingVariables
        )
    }

    private fun classifyIntent(input: String, attachedFileName: String?): IntentClassification {
        val lower = input.lowercase()
        val entities = extractSearchTokens(input)

        val intent = when {
            lower.startsWith("remember") || lower.startsWith("learn this") || lower.startsWith("store this") || lower.startsWith("rule:") ->
                UserIntent.TEACH_MEMORY
            lower.startsWith("define framework") || lower.startsWith("create framework") || lower.startsWith("framework") ->
                UserIntent.TEACH_FRAMEWORK
            lower.startsWith("connect") && (lower.contains("with") || lower.contains("to")) ->
                UserIntent.CONNECT_CONCEPTS
            lower.startsWith("that rule is wrong") || lower.startsWith("that is incorrect") || lower.startsWith("correction:") ->
                UserIntent.CORRECTION
            lower.contains("matrix") || lower.contains("walls") && lower.contains("seats") || lower.contains("vehicle setup") ->
                UserIntent.SYSTEM_ANALYSIS
            lower.contains("what if") || lower.contains("what happens if") || (lower.contains("change") && lower.contains("to")) ->
                UserIntent.SCENARIO_SIMULATION
            input.any { it in "+-*/^%" } && input.any { it.isDigit() } ->
                UserIntent.MATHEMATICAL_CALCULATION
            attachedFileName != null ->
                UserIntent.FILE_ASSIMILATION
            else ->
                UserIntent.DIRECT_QUERY
        }

        val fwName = if (lower.contains("matrix")) "Matrix" else null

        return IntentClassification(
            primaryIntent = intent,
            extractedEntities = entities,
            targetFramework = fwName,
            confidence = 0.96f
        )
    }

    private suspend fun handleTeachingMode(
        input: String,
        intent: IntentClassification,
        steps: MutableList<PipelineStepExecution>,
        attachedFileName: String?,
        attachedFileContent: String?
    ): CognitiveResult? {
        val lower = input.lowercase()

        // 1. Remember / Store
        val rememberPrefix = Regex("""^(?:remember\s+(?:this:?|that:?)|learn\s+(?:this:?)|store\s+(?:this:?)|rule:?)\s*(.+)""", RegexOption.IGNORE_CASE).find(input)
        if (rememberPrefix != null) {
            val contentToRemember = rememberPrefix.groupValues[1].trim()
            val title = extractTitle(contentToRemember)
            val type = determineType(contentToRemember)
            val node = MemoryNode(
                title = title,
                content = contentToRemember,
                type = type,
                epistemicStatus = EpistemicStatus.USER_DEFINED_RULE,
                source = "user_direct_teaching"
            )
            val id = dao.insertMemory(node)
            steps.add(
                PipelineStepExecution(
                    stepName = "Memory Assimilation",
                    summary = "Saved node #$id ($type) to SQLite database",
                    durationMs = 5L
                )
            )

            val answer = "Stored into persistent long-term memory (ID: #$id, Type: $type, Status: USER_DEFINED_RULE):\n\n\"$contentToRemember\""
            dao.insertChatMessage(
                ChatMessage(
                    isUser = false,
                    text = answer,
                    reasoningSummary = "Committed rule directly into persistent Room database index.",
                    retrievedMemoryCount = 0
                )
            )
            return CognitiveResult(
                finalResponse = answer,
                reasoningSummary = "User Teaching Mode: Committed to long-term memory with active index.",
                intentClassification = intent,
                pipelineSteps = steps,
                retrievedMemories = listOf(node.copy(id = id)),
                calculationPerformed = null,
                epistemicStatus = EpistemicStatus.USER_DEFINED_RULE,
                wasLearningCommitted = true,
                activeFramework = null
            )
        }

        // 2. Framework definition
        val frameworkMatch = Regex("""^(?:define\s+framework|create\s+framework|framework)\s+([a-zA-Z0-9_\-]+)[:\s]+(.+)""", RegexOption.IGNORE_CASE).find(input)
        if (frameworkMatch != null) {
            val name = frameworkMatch.groupValues[1].trim()
            val desc = frameworkMatch.groupValues[2].trim()
            val framework = UserFramework(
                name = name,
                description = desc,
                rulesJson = "[\"$desc\"]"
            )
            val fid = dao.insertFramework(framework)
            dao.insertMemory(
                MemoryNode(
                    title = "Framework: $name",
                    content = desc,
                    type = MemoryType.FRAMEWORK,
                    frameworkName = name,
                    epistemicStatus = EpistemicStatus.USER_DEFINED_RULE
                )
            )
            steps.add(
                PipelineStepExecution(
                    stepName = "Framework Creation",
                    summary = "Registered framework '$name' (#$fid)",
                    durationMs = 4L
                )
            )
            val answer = "Custom Framework '$name' persistently registered (ID: #$fid).\nDescription & Rules: \"$desc\"\n\nJARVIS will now automatically retrieve and apply '$name' whenever referenced in future analysis."
            dao.insertChatMessage(
                ChatMessage(
                    isUser = false,
                    text = answer,
                    reasoningSummary = "Framework Engine committed new framework definition.",
                    retrievedMemoryCount = 0
                )
            )
            return CognitiveResult(
                finalResponse = answer,
                reasoningSummary = "Framework Engine committed new framework '$name'.",
                intentClassification = intent,
                pipelineSteps = steps,
                retrievedMemories = emptyList(),
                calculationPerformed = null,
                epistemicStatus = EpistemicStatus.USER_DEFINED_RULE,
                wasLearningCommitted = true,
                activeFramework = framework
            )
        }

        // 3. Connect concepts
        val connectMatch = Regex("""^connect\s+([a-zA-Z0-9_\s]+)\s+(?:to|with|and)\s+([a-zA-Z0-9_\s]+)(?:\s+as\s+([a-zA-Z_]+))?(?::\s*(.+))?""", RegexOption.IGNORE_CASE).find(input)
        if (connectMatch != null) {
            val conceptA = connectMatch.groupValues[1].trim()
            val conceptB = connectMatch.groupValues[2].trim()
            val relStr = connectMatch.groupValues.getOrNull(3)?.trim()?.uppercase() ?: "RELATED_TO"
            val desc = connectMatch.groupValues.getOrNull(4)?.trim() ?: "Direct user link"
            val relationType = runCatching { RelationType.valueOf(relStr) }.getOrDefault(RelationType.RELATED_TO)

            val rel = KnowledgeRelation(
                fromConcept = conceptA,
                toConcept = conceptB,
                relationType = relationType,
                description = desc
            )
            val rid = dao.insertRelation(rel)
            steps.add(
                PipelineStepExecution(
                    stepName = "Knowledge Graph Edge",
                    summary = "Connected [$conceptA] -> [$relationType] -> [$conceptB]",
                    durationMs = 4L
                )
            )
            val answer = "Knowledge Graph connection mapped (Relation #$rid):\n[$conceptA] ➔ [$relationType] ➔ [$conceptB]\nContext: $desc"
            dao.insertChatMessage(
                ChatMessage(
                    isUser = false,
                    text = answer,
                    reasoningSummary = "Knowledge Graph engine updated with directed semantic relation edge."
                )
            )
            return CognitiveResult(
                finalResponse = answer,
                reasoningSummary = "Knowledge Graph engine connected concepts.",
                intentClassification = intent,
                pipelineSteps = steps,
                retrievedMemories = emptyList(),
                calculationPerformed = null,
                epistemicStatus = EpistemicStatus.FACT,
                wasLearningCommitted = true,
                activeFramework = null
            )
        }

        // 4. Correction
        if (lower.startsWith("that rule is wrong") || lower.startsWith("that is incorrect") || lower.startsWith("correction:")) {
            val correctionDetails = input.substringAfter(':').ifEmpty { input.substringAfter("wrong") }.trim()
            val memory = MemoryNode(
                title = "Correction on previous premise",
                content = correctionDetails,
                type = MemoryType.CORRECTION,
                epistemicStatus = EpistemicStatus.FACT,
                source = "user_correction"
            )
            val cid = dao.insertMemory(memory)
            steps.add(
                PipelineStepExecution(
                    stepName = "Correction Invalidation",
                    summary = "Recorded correction #$cid",
                    durationMs = 3L
                )
            )
            val answer = "Correction recorded in permanent memory.\nStored update: \"$correctionDetails\"\nJARVIS will prioritize this correction over previous inconsistent premises."
            dao.insertChatMessage(
                ChatMessage(
                    isUser = false,
                    text = answer,
                    reasoningSummary = "Adaptive Learning Engine recorded user correction node."
                )
            )
            return CognitiveResult(
                finalResponse = answer,
                reasoningSummary = "Adaptive Learning Engine updated with user correction.",
                intentClassification = intent,
                pipelineSteps = steps,
                retrievedMemories = listOf(memory),
                calculationPerformed = null,
                epistemicStatus = EpistemicStatus.FACT,
                wasLearningCommitted = true,
                activeFramework = null
            )
        }

        return null
    }

    private fun extractSearchTokens(input: String): List<String> {
        return input.split(Regex("[\\s,;.:?!()\"']+"))
            .map { it.trim().lowercase() }
            .filter { it.length > 2 && it !in commonStopWords }
            .distinct()
    }

    private fun rankAndRetrieveMemories(tokens: List<String>, allMemories: List<MemoryNode>): List<MemoryNode> {
        val scored = allMemories.map { mem ->
            var score = 0f
            val lowerTitle = mem.title.lowercase()
            val lowerContent = mem.content.lowercase()
            val lowerTags = mem.tags.lowercase()

            for (t in tokens) {
                if (lowerTitle.contains(t)) score += 3.0f
                if (lowerContent.contains(t)) score += 1.5f
                if (lowerTags.contains(t)) score += 2.0f
            }

            if (mem.type == MemoryType.FRAMEWORK || mem.type == MemoryType.RULE) {
                score += 0.5f
            }

            Pair(mem, score * mem.importance)
        }

        return scored
            .filter { it.second > 0.5f }
            .sortedByDescending { it.second }
            .take(6)
            .map { it.first }
    }

    private fun extractTitle(content: String): String {
        val firstSentence = content.split('.', '\n').firstOrNull()?.trim() ?: content
        return firstSentence.take(40)
    }

    private fun determineType(content: String): MemoryType {
        val lower = content.lowercase()
        return when {
            lower.contains("rule") -> MemoryType.RULE
            lower.contains("formula") || lower.contains("=") -> MemoryType.FORMULA
            lower.contains("framework") -> MemoryType.FRAMEWORK
            lower.contains("observation") -> MemoryType.OBSERVATION
            lower.contains("experiment") -> MemoryType.EXPERIMENT
            lower.contains("preference") -> MemoryType.PREFERENCE
            else -> MemoryType.FACT
        }
    }

    private val commonStopWords = setOf(
        "the", "and", "for", "with", "that", "this", "what", "from", "have", "you",
        "are", "was", "how", "why", "who", "all", "can", "tell", "does", "about"
    )
}
