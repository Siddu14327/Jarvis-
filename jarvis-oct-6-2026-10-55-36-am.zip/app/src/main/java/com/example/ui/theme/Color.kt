package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TechIndigo80 = Color(0xFFD0BCFF)
val TechCyan80 = Color(0xFF80DEEA)
val TechAmber80 = Color(0xFFFFD54F)

val TechIndigo40 = Color(0xFF6750A4)
val TechCyan40 = Color(0xFF00838F)
val TechAmber40 = Color(0xFFF57F17)

val DarkSurface = Color(0xFF0F141C)
val DarkSurfaceVariant = Color(0xFF1B2230)
val DarkBackground = Color(0xFF0A0D14)
