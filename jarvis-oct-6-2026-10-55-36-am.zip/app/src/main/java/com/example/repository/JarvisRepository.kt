package com.example.repository

import com.example.db.JarvisDao
import com.example.model.ChatMessage
import com.example.model.KnowledgeRelation
import com.example.model.MemoryNode
import com.example.model.ReasoningExperience
import com.example.model.UserFramework
import kotlinx.coroutines.flow.Flow

class JarvisRepository(private val dao: JarvisDao) {

    val activeMemoriesFlow: Flow<List<MemoryNode>> = dao.getAllActiveMemoriesFlow()
    val relationsFlow: Flow<List<KnowledgeRelation>> = dao.getAllRelationsFlow()
    val frameworksFlow: Flow<List<UserFramework>> = dao.getAllFrameworksFlow()
    val experiencesFlow: Flow<List<ReasoningExperience>> = dao.getAllExperiencesFlow()
    val chatMessagesFlow: Flow<List<ChatMessage>> = dao.getAllChatMessagesFlow()

    suspend fun insertMemory(node: MemoryNode): Long = dao.insertMemory(node)
    suspend fun deleteMemory(id: Long) = dao.deleteMemory(id)

    suspend fun insertRelation(relation: KnowledgeRelation): Long = dao.insertRelation(relation)
    suspend fun deleteRelation(id: Long) = dao.deleteRelation(id)

    suspend fun insertFramework(framework: UserFramework): Long = dao.insertFramework(framework)
    suspend fun deleteFramework(id: Long) = dao.deleteFramework(id)

    suspend fun insertChatMessage(message: ChatMessage): Long = dao.insertChatMessage(message)
    suspend fun clearChatMessages() = dao.clearChatMessages()
}
