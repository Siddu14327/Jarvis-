package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.example.ui.JarvisMainScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.JarvisViewModel
import com.example.viewmodel.JarvisViewModelFactory

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels {
        JarvisViewModelFactory(applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val filePickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocument()
                ) { uri: Uri? ->
                    uri?.let { viewModel.attachFile(it) }
                }

                JarvisMainScreen(
                    viewModel = viewModel,
                    onPickFile = {
                        filePickerLauncher.launch(
                            arrayOf(
                                "text/*",
                                "image/*",
                                "application/pdf",
                                "application/json",
                                "application/zip",
                                "*/*"
                            )
                        )
                    }
                )
            }
        }
    }
}
